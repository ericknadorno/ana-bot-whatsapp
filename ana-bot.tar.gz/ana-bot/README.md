# 🤖 Ana Bot - Assistente Pessoal para WhatsApp

[![GitHub](https://img.shields.io/badge/GitHub-ana--bot--whatsapp-blue?logo=github)](https://github.com/ericknadorno/ana-bot-whatsapp)
[![Node.js](https://img.shields.io/badge/Node.js-20+-green?logo=node.js)](https://nodejs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5-blue?logo=typescript)](https://www.typescriptlang.org/)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

Ana é um bot de WhatsApp pessoal que ajuda você a gerenciar tarefas, reuniões e despesas, tudo dentro do WhatsApp. Desenvolvido em Node.js com TypeScript.

📦 **Repositório**: https://github.com/ericknadorno/ana-bot-whatsapp

## ✨ Funcionalidades

- 📝 **Gerenciamento de Tarefas**: Criar, listar, concluir e remover tarefas com datas e tags
- 📅 **Reuniões**: Agendar reuniões com lembretes automáticos 30 minutos antes
- 💰 **Controle de Despesas**: Registrar e consultar gastos por período e categoria
- ☀️ **Resumo Diário**: Receba um resumo matinal automático com suas tarefas e reuniões do dia
- 📊 **Relatórios**: Visualize estatísticas de produtividade e gastos
- 🔄 **Backup**: Exporte seus dados em formato CSV

## 🚀 Instalação

### Opção 1: Clone do GitHub

```bash
# Clone o repositório
git clone https://github.com/ericknadorno/ana-bot-whatsapp.git
cd ana-bot-whatsapp

# Instale as dependências
npm install

# Configure as variáveis de ambiente
cp .env.example .env
# Edite o .env com seus dados

# Compile o TypeScript
npm run build

# Inicie o bot
npm start
```

### Opção 2: Deploy no Replit

#### 1. Criar Projeto no Replit

1. Acesse [Replit](https://replit.com)
2. Clique em "Create Repl"
3. Selecione "Import from GitHub"
4. Cole a URL: `https://github.com/ericknadorno/ana-bot-whatsapp`
5. Aguarde a importação

### 2. Configurar Variáveis de Ambiente

No Replit, vá em "Tools" → "Secrets" e adicione:

```
TZ=Europe/Lisbon
OWNER_NUMBER=3519xxxxxxxx@c.us
MORNING_DIGEST_HOUR=8
MORNING_DIGEST_MINUTE=0
LOG_LEVEL=info
```

**Importante**: 
- `OWNER_NUMBER` deve estar no formato completo do WhatsApp: `[código do país][número]@c.us`
- Para obter seu número no formato correto, você pode primeiro rodar o bot sem essa variável e ele mostrará o formato nos logs

### 3. Instalar Dependências

No Shell do Replit, execute:

```bash
npm install
```

### 4. Compilar TypeScript

```bash
npm run build
```

### 5. Iniciar o Bot

```bash
npm start
```

Ou simplesmente clique no botão "Run" do Replit.

### 6. Conectar WhatsApp

1. Quando o bot iniciar, um QR Code aparecerá no console
2. Abra o WhatsApp no seu celular
3. Vá em **Configurações** → **Aparelhos Conectados** → **Conectar Aparelho**
4. Escaneie o QR Code mostrado no console
5. Aguarde a mensagem "WhatsApp client ready"

Pronto! Agora você pode conversar com a Ana pelo WhatsApp.

## 📱 Comandos Disponíveis

### Ajuda
```
ajuda
```

### Tarefas

**Adicionar tarefa:**
```
add tarefa pagar conta de luz
add tarefa reunião com cliente às 14h
add tarefa comprar presente amanhã às 10h #pessoal
add tarefa enviar relatório dia 15/11 #trabalho
```

**Listar tarefas:**
```
minhas tarefas
minhas tarefas hoje
minhas tarefas semana
```

**Concluir tarefa:**
```
concluir tarefa 5
concluir tarefa pagar conta
```

**Remover tarefa:**
```
remover tarefa 5
```

### Reuniões

**Criar reunião:**
```
reunião hoje às 15h: alinhamento de projeto
reunião amanhã às 10h: apresentação @Sala 2
reunião 15/11 14:30: reunião com cliente @Escritório com João e Maria
```

**Listar reuniões:**
```
listar reuniões
listar reuniões hoje
listar reuniões semana
```

**Adiar lembrete (snooze):**
```
soneca 3 15m
soneca 3 30m
soneca 3 1h
```

### Despesas

**Registrar despesa:**
```
despesa 12.50 almoço
despesa 45 transporte uber para reunião
despesa 89.90 mercado compras do mês
```

**Ver gastos:**
```
gastos
gastos hoje
gastos semana
gastos mês
```

### Relatórios e Configurações

**Relatório completo:**
```
relatório
relatório semana
relatório mês
```

**Configurar horário do resumo diário:**
```
config resumo 07:30
config resumo 09:00
```

**Backup de dados:**
```
backup
```

## 🏗️ Estrutura do Projeto

```
ana-bot/
├── src/
│   ├── index.ts              # Ponto de entrada
│   ├── bot.ts                # Lógica do bot WhatsApp
│   ├── scheduler.ts          # Agendamentos (cron jobs)
│   ├── parsers.ts            # Parse de comandos em linguagem natural
│   ├── messages.ts           # Templates de mensagens
│   ├── commands/             # Handlers de comandos
│   │   ├── tasks.ts
│   │   ├── meetings.ts
│   │   ├── expenses.ts
│   │   └── config.ts
│   ├── db/                   # Camada de dados
│   │   ├── sqlite.ts
│   │   └── repositories.ts
│   └── utils/                # Utilitários
│       ├── time.ts
│       └── text.ts
├── data/                     # Banco de dados SQLite
│   └── ana.db
├── schema.sql                # Schema do banco
├── package.json
├── tsconfig.json
└── README.md
```

## 🗄️ Banco de Dados

O bot usa SQLite para persistência. O arquivo `ana.db` é criado automaticamente na pasta `data/` na primeira execução.

### Tabelas:

- **tasks**: Armazena tarefas com título, prazo, tags e status
- **meetings**: Armazena reuniões com hora, local e participantes
- **expenses**: Armazena despesas com valor, categoria e notas
- **settings**: Configurações do bot

## ⚙️ Configurações Avançadas

### Alterar Fuso Horário

Edite a variável `TZ` no arquivo `.env` ou nos Secrets do Replit:
```
TZ=America/Sao_Paulo
TZ=Europe/Lisbon
```

### Desabilitar Lembretes de Reunião

Por padrão, todas as reuniões têm lembretes 30 minutos antes. Não é possível desabilitar por comando, mas você pode modificar o código em `src/db/repositories.ts`.

### Logs

Ajuste o nível de log com a variável `LOG_LEVEL`:
- `debug`: Muito detalhado
- `info`: Normal (recomendado)
- `warn`: Apenas avisos
- `error`: Apenas erros

## 🔧 Troubleshooting

### QR Code não aparece

1. Verifique se o Chromium está instalado corretamente
2. No Replit, certifique-se que o `replit.nix` está configurado
3. Tente limpar a sessão: `rm -rf .wwebjs_auth/` e reinicie

### Bot não responde

1. Verifique se o `OWNER_NUMBER` está correto
2. Confirme que o formato é `3519xxxxxxxx@c.us`
3. Verifique os logs com `LOG_LEVEL=debug`

### "Authentication failure"

1. Delete a pasta `.wwebjs_auth/`
2. Reinicie o bot
3. Escaneie o QR Code novamente

### Bot desconecta frequentemente

No Replit, isso pode ocorrer se o projeto ficar inativo. Soluções:

1. Use o Replit Always On (plano pago)
2. Configure um uptime monitor externo (como UptimeRobot)
3. Faça ping no endpoint `/health` a cada 5 minutos

### Banco de dados corrompido

```bash
# Backup manual
cp data/ana.db data/ana.db.backup

# Recriar banco
rm data/ana.db
# Reinicie o bot - ele criará um novo banco
```

## 📊 Exemplos de Uso

### Rotina Matinal
```
# Ana envia automaticamente às 8h:
☀️ Bom dia!

Aqui está o seu plano para hoje:

📝 Tarefas (3):
• #12: Enviar proposta - 09:00 #trabalho
• #15: Academia - 18:00 #saúde
• #18: Ligar para dentista #pessoal

📅 Reuniões (2):
• 10:00 - Daily standup @Zoom
• 15:00 - Apresentação de resultados @Sala de Reuniões

💡 Dica: responda "minhas tarefas" ou "listar reuniões" a qualquer momento.
```

### Durante o Dia
```
Você: add tarefa comprar leite às 19h
Ana: ✅ Tarefa criada (#19): comprar leite
     ⏰ hoje às 19:00

Você: reunião amanhã às 14h: code review com equipe @Sala 3
Ana: 📅 Reunião agendada (#8): code review com equipe
     ⏰ amanhã às 14:00
     📍 Sala 3
     
     💡 Você receberá um lembrete 30 minutos antes.

Você: despesa 8.50 café
Ana: 💰 Despesa registrada (#45): 8,50 €
     📂 café

Você: gastos hoje
Ana: 💰 Gastos (hoje):
     
     Total: 23,50 €
     
     Por categoria:
     • café: 8,50 €
     • almoço: 15,00 €
```

### Lembrete de Reunião
```
# 30 minutos antes da reunião:
Ana: ⏰ Lembrete de Reunião

code review com equipe
⏰ Em 30 minutos (14:00)
📍 Sala 3

Você: soneca 8 15m
Ana: ⏰ Lembrete adiado para hoje às 14:15
```

## 🔐 Segurança

- Use sempre `OWNER_NUMBER` para restringir acesso
- Não compartilhe o QR Code ou sessão WhatsApp
- Faça backups regulares do banco de dados
- Mantenha as dependências atualizadas

## 📝 Checklist de Testes

Use este checklist para validar a instalação:

- [ ] Bot conecta ao WhatsApp e mostra "ready"
- [ ] Comando `ajuda` retorna lista de comandos
- [ ] `add tarefa teste` cria tarefa
- [ ] `minhas tarefas` lista a tarefa criada
- [ ] `concluir tarefa 1` marca como concluída
- [ ] `reunião amanhã às 10h: teste` cria reunião
- [ ] `listar reuniões` mostra a reunião
- [ ] `despesa 10 teste` registra despesa
- [ ] `gastos hoje` mostra o total
- [ ] `relatório hoje` gera relatório
- [ ] `config resumo 07:30` altera horário
- [ ] `backup` retorna CSV com dados
- [ ] Resumo diário é enviado no horário configurado
- [ ] Lembrete de reunião é enviado 30min antes

## 🤝 Contribuindo

Sugestões e melhorias são bem-vindas! Este é um projeto pessoal, mas sinta-se livre para adaptá-lo às suas necessidades.

## 📄 Licença

MIT License - Sinta-se livre para usar e modificar.

## 🙏 Agradecimentos

Construído com:
- [whatsapp-web.js](https://github.com/pedroslopez/whatsapp-web.js)
- [node-cron](https://github.com/node-cron/node-cron)
- [better-sqlite3](https://github.com/WiseLibs/better-sqlite3)
- [Luxon](https://moment.github.io/luxon/)
- [Chrono](https://github.com/wanasit/chrono)

---

**Nota**: Este bot é para uso pessoal. Certifique-se de seguir os Termos de Serviço do WhatsApp ao usá-lo.
